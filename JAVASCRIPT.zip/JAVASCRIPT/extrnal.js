document.write("HELLO WORLD   ");
document.write("Thisis javascript class");